﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Practise.Areas.AdminPanel.Data;
using Practise.DataAccessLayer;
using Practise.Models;

namespace Practise.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class ProductController : Controller
    {
        private readonly AppDbContext _dbContext;

        public ProductController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Create()
        {
            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children)
                .ToListAsync();
            ViewBag.ParentCategories = parentCategories;
            ViewBag.ChildCategories = parentCategories[0].Children.ToList();

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product, int parentCategoryId, int? childCategoryId)
        {
            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children)
                .ToListAsync();
            ViewBag.ParentCategories = parentCategories;
            ViewBag.ChildCategories = parentCategories[0].Children.ToList();

            if (!ModelState.IsValid)
                return View();

            var isExist = await _dbContext.Products.AnyAsync(x => x.Title == product.Title);
            if (isExist)
            {
                ModelState.AddModelError("Title", "This product is already exist.");
                return View();
            }

            var existParent = parentCategories.Find(x => x.Id == parentCategoryId);
            if (existParent == null)
                return NotFound();

            if (childCategoryId != null)
            {
                var allChildren = parentCategories.SelectMany(x => x.Children).ToList();
                //if (!allChildren.Any(x => x.Id == childCategoryId))
                //{
                //    return NotFound();
                //}

                if (allChildren.All(x => x.Id != childCategoryId))
                {
                    return NotFound();
                }
            }

            if (product.Photos == null || product.Photos.Length == 0)
            {
                ModelState.AddModelError("Photos", "Please upload photo");
                return View();
            }

            var productImages = new List<ProductImage>();
            foreach (var photo in product.Photos)
            {
                if (!photo.IsImage())
                {
                    ModelState.AddModelError("Photos", "Zehmet olmasa yalniz shekil sechin");
                    return View();
                }

                if (!photo.IsSizeAllowed(1))
                {
                    ModelState.AddModelError("Photos", "Zehmet olmasa 1 Mb-dan az olan shekil sechin");
                    return View();
                }

                var fileName = await FileUtil.GenerateFile(Constants.ImageFolderPath, photo);

                var productImage = new ProductImage
                {
                    Name = fileName,
                    Product = product
                };
                productImages.Add(productImage);
            }

            product.ProductImages = productImages;

            var productCategories = new List<ProductCategory>();

            var parentProductCategory = new ProductCategory
            {
                ProductId = product.Id,
                CategoryId = parentCategoryId
            };
            productCategories.Add(parentProductCategory);

            if (childCategoryId != null)
            {
                var childProductCategory = new ProductCategory
                {
                    ProductId = product.Id,
                    CategoryId = (int)childCategoryId
                };
                productCategories.Add(childProductCategory);
            }

            product.ProductCategories = productCategories;

            await _dbContext.Products.AddAsync(product);
            await _dbContext.SaveChangesAsync();

            return Content("Ok");
        }

        public async Task<IActionResult> LoadChildren(int? parentCategoryId)
        {
            if (parentCategoryId == null)
                return NotFound();

            var category = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain && x.Id == parentCategoryId)
                .Include(x => x.Children).FirstOrDefaultAsync();

            return PartialView("_ProductChildrenPartial", category.Children.ToList());
        }
    }
}
